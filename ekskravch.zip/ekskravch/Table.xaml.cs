﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ekskravch
{
    /// <summary>
    /// Логика взаимодействия для Table.xaml
    /// </summary>
    public partial class Table : Page
    {
        string loginperson;
        ekskravchEntities context;
        public Table(string loginperson1)
        {
            InitializeComponent();
            loginperson = loginperson1;
            context = new ekskravchEntities();
            dg.ItemsSource = context.Order.ToList();
            cmb.ItemsSource = context.Order.ToList();
            if (loginperson == "Manager" || loginperson == "Client")
            {
                del.Visibility = Visibility.Hidden;
                addde.Visibility = Visibility.Hidden;
                
            }

        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            dg.ItemsSource = context.Order.ToList();
        }

        private void cmb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Filter();
        }

        private void search_TextChanged(object sender, TextChangedEventArgs e)
        {
            Filter();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (loginperson == "Admin")
            {
                NavigationService.Navigate(new Add((sender as Button).DataContext as Order));
            }
            else
            {
                MessageBox.Show("Недостаточно доступа");
            }
        }
        public void Filter()
        {
            List<Order> orders = context.Order.ToList();
            if (cmb.SelectedItem == null && search.Text == "")
                return;
            if (cmb.SelectedItem != null)
            {
                Order order = cmb.SelectedItem as Order;
                orders = orders.Where(p => p.Status == order.Status).ToList();
            }
            orders = orders.Where(p => p.Dates.ToLower().Contains(search.Text.ToLower())).ToList();
            dg.ItemsSource = orders;

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Внимание","Вы уверены?", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                var row = dg.SelectedItem as Order;
                context.Order.Remove(row);
                context.SaveChanges();
                dg.ItemsSource = context.Order.ToList();
            }
        }

        private void addde_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Add(null));

        }
    }
}
