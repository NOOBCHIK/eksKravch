﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ekskravch
{
    /// <summary>
    /// Логика взаимодействия для Add.xaml
    /// </summary>
    public partial class Add : Page
    {
        public Order corder = new Order();
        ekskravchEntities context;
        public Add(Order selected)
        {
            InitializeComponent();
            context = new ekskravchEntities();
            if (selected != null)
            {
                corder = selected;
            }
            DataContext = corder;
            cmbx.ItemsSource = context.Place.ToList();
        }

        private void addd_Click(object sender, RoutedEventArgs e)
        {
            if (corder.ID == 0)
            {
                context.Order.Add(corder);
            }
            try
            {
                context.SaveChanges();
                MessageBox.Show("Успешно");
                this.NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
